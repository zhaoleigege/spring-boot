package com.springbootdev.examples.security.basic.exception;

public class ValidationException extends AppGenericException {

    public ValidationException(String message) {
        super(message);
    }
}
