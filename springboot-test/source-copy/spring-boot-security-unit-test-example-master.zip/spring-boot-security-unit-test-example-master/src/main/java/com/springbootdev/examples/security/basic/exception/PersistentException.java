package com.springbootdev.examples.security.basic.exception;

public class PersistentException extends AppGenericException {

    public PersistentException(String message) {
        super(message);
    }
}
