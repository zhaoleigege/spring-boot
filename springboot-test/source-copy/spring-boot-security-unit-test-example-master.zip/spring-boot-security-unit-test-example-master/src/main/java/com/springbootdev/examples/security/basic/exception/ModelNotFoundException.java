package com.springbootdev.examples.security.basic.exception;

public class ModelNotFoundException extends AppGenericException {

    public ModelNotFoundException(String message) {
        super(message);
    }
}
