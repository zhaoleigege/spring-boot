package com.springbootdev.examples.security.basic.exception;

public class AppGenericException extends Exception {

    public AppGenericException(String message) {
        super(message);
    }
}
